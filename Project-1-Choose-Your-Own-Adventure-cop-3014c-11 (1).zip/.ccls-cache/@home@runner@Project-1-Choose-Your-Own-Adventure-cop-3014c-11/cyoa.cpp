// cyoa.cpp
// Zachary Wilson

#include <iomanip>
#include <iostream>
using namespace std;

int main() {
  cout << "You wake up in a cold sweat, sitting on your living room floor. You "
          "could’ve sworn you went to sleep in your bed last night. A white "
          "lantern sits on the table in the center of the room. It looks alien "
          "in origin, as it glows a white so pure that it doesn’t pain the "
          "eyes to see, despite it being bright enough to illuminate the "
          "darkest shadows in the room. “Choose” says the lantern. There was "
          "no language spoken and no sound heard, it was as if the lantern "
          "imparted the thought directly into your head.\n\nWhat do you do "
          "next?\n\n";

  cout << "1 - Do nothing\n"
          "2 - \"Choose what?\"\n"
          "3 - Run\n\n";

  int choice;
  int schoice;
  cin >> choice;
  int hope;
  int cowardice;
  
  switch (choice) {
    case 1:
      cout << "\nYou're instantly teleported to a bar you don't recognize. The "
              "bar is nearly full, but no one seems to have noticed your "
              "sudden appearance. You look to your right and see two people in "
              "a confrontation, one of them clearly bigger than the other. The "
              "bigger one clearly bullying the smaller one in a drunken, "
              "irrational outbursts\n\nWhat do you do next?\n\n";
      cowardice++;
      break;
  
    case 2:
      cout << "\nBe peace, or chaos, all bring balance. Your choice is no "
              "choice, but has not been chosen. You must choose.\n\nYou're "
              "instantly teleported to a bar you don't recognize. The bar is "
              "nearly full, but no one seems to have noticed your sudden "
              "appearance. You look to your right and see two people in a "
              "confrontation, one of them clearly bigger than the other. The "
              "bigger one clearly bullying the smaller one in a drunken, "
              "irrational outbursts\n\nWhat do you do next?\n\n";
      hope++;
      break;
  
    case 3:
      cout << "\nYou run as fast as you can and finally make it outside. You "
              "look around and find that aliens have invaded and there are no "
              "more heroes to save them. Your city is blown to pieces and you "
              "don't survive :(\n\n\t\t\t\t\t THE END!\n";
      return 1;
  
    default:
      cout << "Invalid input";
      return 1;
  }
  cout << "1 - Intervene\n"
          "2 - Head towards the exit\n";
  cin >> choice;
  // sure you want to leave?
  switch (choice) {
    case 1:
      hope++;
      break;
  
    case 2:
      cout << "You decide to walk towards the exit. On your way out, you hear "
              "the big guy draw a weapon. Someone could get seriously hurt if "
              "you leave\n\nWhat do you do next?\n\n";
      cowardice++;
  
      cout << "1 - Intervene\n"
              "2 - Leave\n";
      cin >> schoice;
      switch (schoice) {
        case 1:
          break;
  
        case 2:
          cout << "You leave the bar and the small guy was killed :(\n\nYou're "
                  "teleported to your room and the lantern has vanished. You "
                  "had the chance to be a hero, though it seems you were not "
                  "ready for the call\n\n\t\t\t\t  THE END!";
          cowardice++;
          if (cowardice == 3) {
            cout
                << "\n\nIt appears you've made 3 out of 3 cowardly descisions. "
                   "You failed to display the altruism of a true hero, nor the "
                   "drive of a true villain. Pray that in your next life God "
                   "doesn't make you an NPC again.\n";
          }
          return 1;
      }
  }
  string bully;
  // intervention
  cout << "You walk towards the two people and split them up, now that you're "
          "closer to them, you recognize the big guy as the same guy who "
          "used to bully you back in grade school.\n\n What was his name "
          "again?\n";
  cin >> bully;

  cout << "\n"
       << bully
       << " doesn't seem to "
          "recognize you since you've gotten much stronger since those "
          "days\n\nWhat do you do next?\n\n";

  cout << "1 - Diffuse the situation\n"
          "2 - Punch him in the face\n"
          "3 - Grab a bottle\n\n";

  cin >> choice;
  
  switch (choice) {
    case 1:
      cout << "You talk to Chad and the victim and your words are teach him "
              "the error of his ways. Your wisdom is guaranteed to forever "
              "change Chad's life and make him a better person for good. A "
              "bystander records your proverbs of wisdom and writes a book "
              "with them, crediting you with every word. Your words are spread "
              "in every country in every language and world peace is set to be "
              "accomplished in just 2 years time. You are a hero to "
              "humanity.\n\n";
      hope++;
  
      cout << "You're teleported back to your living room, in front of the "
              "white lantern. \"You have chosen\", the lantern says. You look "
              "to your hand and see a green ring on your finger. Your ability "
              "to inspire hope in others is among the best the universe has "
              "ever seen. The green ring allows you to channel that hope into "
              "any construct you can imagine. Use these newfound abilities to "
              "inpire others\n";
      if (hope == 3) {
        cout << "Congratulations, you made 3 out of 3 hopeful decisions! Your "
                "actions display true heroism and prove you the perfect green "
                "lantern.\n";
      }
  
      return 1;
  
    case 2:
      cout << "Your welled up rage builds up and you punch Chad in the face, "
              "but that's not enough, you punch him over and over again. Once "
              "you notice that he's bleeding, you pause. You try your best to "
              "have compassion, but it's too late, the anger you feel now goes "
              "far beyond what he actually did to. Now Chad's stunned face has "
              "become a cathartic tool for all the rage you've ever felt. You "
              "finally stop, your hands drenched in blood and veins showing "
              "out of your neck. You were so blinded by rage that you failed "
              "to notice that Chad died many punches ago, yet somehow what you "
              "feel is not remorse, but anger that he was too to take any "
              "more\n\n";
  
      cout << "You're teleported back to your living room, in front of the "
              "white lantern. \"You have chosen\", the lantern says. You look "
              "to your hand and see a red ring on your finger. You are now "
              "part of the Red Lantern Corps. You are determined to be among "
              "the most rageful beings in the entire universe, thus, the ring "
              "allows you to channel that rage into immense power strong "
              "enough to level planets under your leader Atrocitus. Your wrath "
              "awaits\n";
      return 1;
  
    case 3:
      cout << "You grab a bottle off the counter, smash it, and deal a lethal "
              "blow to Chad. The very sight terrifies everyone in the bar. You "
              "suddenly begin monologuing in a shockingly villainous manner, "
              "speaking of world domination and a \"cleansing of the impure\". "
              "One of the bystanders is recording the event and it goes viral. "
              "Your sudden monologue is surprisingly elaborate and both "
              "strikes fear in the hearts of the innocent, and inspiration in "
              "the hearts of the evil. Your manifestos will forever change the "
              "course of human history as they are passed down the "
              "generations.\n\n";
  
      cout << "You're teleported back to your living room, in front of the "
              "white lantern. \"You have chosen\", the lantern says. You look "
              "to your hand and see a yellow ring on your finger. Your ability "
              "to strike fear in the hearts of others is determined to be "
              "among the best in the universe. The ring allows you to channel "
              "the fear you invoke on others, into immense power strong enough "
              "to level planets under your leader Sinestro. Spread your fear "
              "across the universe accordingly\n\n";
  
      return 1;
  }
}